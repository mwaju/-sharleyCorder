
package DbUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Dbconnection {
    public static Connection ConnectDB()throws Exception{
        try{
      Connection conn=null;
      Class.forName("org.sqlite.JDBC");
      conn=DriverManager.getConnection("jdbc:sqlite:database.db");
        return conn;
        }catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }
}
